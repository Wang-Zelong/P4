let currentSlide = 0;
let autoSlideInterval;
const slides = document.querySelectorAll('.slide');

function showSlide(index) {
    slides.forEach((slide, i) => {
        const isActive = i === index;
        slide.style.display = isActive ? 'block' : 'none';
        slide.classList.toggle('active', isActive);
    });
}

function startAutoSlide() {
    autoSlideInterval = setInterval(() => {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }, 3000);
}

function stopAutoSlide() {
    clearInterval(autoSlideInterval);
}

window.onload = () => {
    showSlide(0);
    startAutoSlide();
};

function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(currentSlide);
}

document.getElementById('next').addEventListener('click', nextSlide);
document.getElementById('prev').addEventListener('click', prevSlide);

window.nextSlide = nextSlide;
window.prevSlide = prevSlide;

document.getElementById('menuToggle').addEventListener('click', function () {
    const navLinks = document.getElementById('navLinks');
    navLinks.classList.toggle("show");
});

document.getElementById('registrationForm').addEventListener('submit', (e) => {
    e.preventDefault();
    validateForm();
});

function validateForm() {
    const isValid = [
        validateField('date-of-visit', 'Select visit date', 'visitDateError'),
        validateField('no-of-visitors', 'Select number of visitors', 'visitorsError'),
        validateField('name', 'Name is required', 'nameError'),
        validateField('email', 'Enter a valid email', 'emailError'),
        validateField('dob', 'Select birth date', 'dobError'),
        validateField('gender', 'select your gender', 'genderError'),
        validateField('ticket', 'Choose ticket type', 'ticketError')
    ].every(result => result);

    if (isValid) {
        alert('表单提交成功!');
        document.getElementById('registrationForm').reset();
    }
}

function validateField(id, message, errorId = `${id}Error`) {
    const fieldMap = {
        'name': document.getElementById("name"),
        'email': document.getElementById("email"),
        'dob': document.getElementById("dob"),
        'ticket': document.getElementById("ticket"),
        'no-of-visitors': document.getElementById("no-of-visitors"),
        'date-of-visit': document.getElementById("date-of-visit"),
        'gender': document.querySelector('input[name="gender"]:checked')
    };

    const errorMap = {
        'name': document.getElementById("nameError"),
        'email': document.getElementById("emailError"),
        'dob': document.getElementById("dobError"),
        'ticket': document.getElementById("ticketError"),
        'no-of-visitors': document.getElementById("visitorsError"),
        'date-of-visit': document.getElementById("visitDateError"),
        'gender': document.getElementById("genderError")
    };

    const field = fieldMap[id] || document.getElementById(id);
    const errorElement = errorMap[id] || document.getElementById(errorId);

    if (!field?.value?.trim()) {
        errorElement.textContent = message;
        return false;
    }
    errorElement.textContent = '';
    return true;
}

// 商品数据加载与展示
let products = [];
let cart = [];
// 在文件开头添加这些引用
const cartButton = document.getElementById('cartButton');
const cartCounter = document.getElementById('cartCounter');
const productsBox = document.getElementById('productsBox');
const cartForm = document.getElementById('cartForm');
const searchBar = document.getElementById('searchBar'); // 新增搜索框引用


document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    // 移除checkoutBtn相关操作
});

async function loadProducts() {
    try {
        const response = await fetch('./ghibli_merchandise.json');
        products = await response.json();
        renderProducts(products);
    } catch (error) {
        console.error('Failed to load products:', error);
    }
}

function renderProducts(productsArray) {
    const container = document.getElementById('productsContainer');
    container.innerHTML = ''; // 清空容器

    productsArray.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        // 使用模板字符串保持代码可读性
        card.innerHTML = `            <img src="assets/${product.id}.jpg" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>$${product.price.toFixed(2)}</p>
            <button class="add-to-cart" data-id="${product.id}">Add To Cart</button>
        `;
        container.appendChild(card);
    });
}

// 搜索功能（添加防抖优化性能）
let searchTimeout;
document.getElementById('searchBar').addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        const searchTerm = e.target.value.trim().toLowerCase();
        const filtered = products.filter(p =>
            p.name.toLowerCase().includes(searchTerm) ||
            p.description.toLowerCase().includes(searchTerm)
        );
        renderProducts(filtered);
    }, 300);
});

cartButton.addEventListener('click', () => {
    const cartVisible = !cartForm.classList.contains('hidden');

    if (!cartVisible) {
        productsBox.classList.add('hidden');
        cartForm.classList.remove('hidden');
        renderCartForm();
    } else {
        productsBox.classList.remove('hidden');
        cartForm.classList.add('hidden');
    }
});

// 修改后的updateCartUI
function updateCartUI() {
    cartCounter.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    localStorage.setItem('cart', JSON.stringify(cart));
}

// 修改后的renderCartForm函数
function renderCartForm() {
    const container = cartForm.querySelector('.cart-items');
    container.innerHTML = '';

    // 添加关闭按钮
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.style.position = 'absolute';
    closeBtn.style.right = '15px';
    closeBtn.style.top = '10px';
    closeBtn.style.fontSize = '24px';
    closeBtn.style.background = 'none';
    closeBtn.style.border = 'none';
    closeBtn.style.cursor = 'pointer';
    closeBtn.addEventListener('click', () => {
        productsBox.classList.remove('hidden');
        cartForm.classList.add('hidden');
    });

    cart.forEach(item => {
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `            <img src="assets/${item.id}.jpg" alt="${item.name}">
            <div>
                <h4>${item.name}</h4>
                <p>单价: $${item.price.toFixed(2)}</p>
            </div>
            <div class="quantity-controls">
                <button class="decrease" data-id="${item.id}">-</button>
                <span>${item.quantity}</span>
                <button class="increase" data-id="${item.id}">+</button>
            </div>
            <button class="remove" data-id="${item.id}">删除</button>
        `;
        container.appendChild(div);
    });

    // 更新总价
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('totalPrice').textContent = total.toFixed(2);
}

// 修改后的购物车操作事件委托
document.addEventListener('click', (e) => {
    const target = e.target;

    // 处理添加到购物车
    if(target.classList.contains('add-to-cart')) {
        const productId = target.dataset.id;
        const product = products.find(p => p.id === productId);
        const existingItem = cart.find(item => item.id === productId);

        if(existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCartUI();
    }

    // 处理购物车操作
    if(target.closest('.decrease')) {
        const id = target.dataset.id;
        const item = cart.find(i => i.id === id);
        if(item.quantity > 1) item.quantity--;
        renderCartForm();
    }

    if(target.closest('.increase')) {
        const id = target.dataset.id;
        cart.find(i => i.id === id).quantity++;
        renderCartForm();
    }

    if(target.closest('.remove')) {
        const id = target.dataset.id;
        cart = cart.filter(i => i.id !== id);
        renderCartForm();
    }

    updateCartUI();
});

// 初始化加载购物车
document.addEventListener('DOMContentLoaded', () => {
    const savedCart = localStorage.getItem('cart');
    if(savedCart) cart = JSON.parse(savedCart);
    updateCartUI();
});

// 在script.js中添加以下代码
document.getElementById('confirmCheckout').addEventListener('click', () => {
    document.querySelector('.cart-items').classList.add('hidden');
    document.querySelector('.cart-summary').classList.add('hidden');
    document.getElementById('checkoutForm').classList.remove('hidden');
});

document.getElementById('paymentForm').addEventListener('submit', (e) => {
    e.preventDefault();

    // 简单表单验证
    const formValid = [
        validateField('fullName', 'Enter full name'),
        validateField('registrationEmail', 'Enter valid email'),
        validateField('address', 'Enter address'),
        validateField('paymentMethod', 'Select payment method'),
        validateField('cardNumber', 'Enter valid card number'),
        validateField('expiryDate', 'Select expiry date'),
        validateField('cvv', 'Enter valid CVV')
    ].every(valid => valid);

    if (formValid) {
        // 显示成功信息
        const total = document.getElementById('totalPrice').textContent;
        const email = document.getElementById('email').value;

        document.getElementById('checkoutForm').classList.add('hidden');
        document.getElementById('purchaseSuccess').classList.remove('hidden');
        document.getElementById('successAmount').textContent = total;
        document.getElementById('successEmail').textContent = email;

        // 清空购物车
        cart = [];
        localStorage.removeItem('cart');
        updateCartUI();

        // 3秒后重置界面
        setTimeout(() => {
            document.getElementById('cartForm').classList.add('hidden');
            document.getElementById('productsBox').classList.remove('hidden');
            document.querySelector('.cart-items').classList.remove('hidden');
            document.querySelector('.cart-summary').classList.remove('hidden');
            document.getElementById('purchaseSuccess').classList.add('hidden');
        }, 3000);
    }
});

// 通用表单验证函数
function validateField(id, errorMsg) {
    const field = document.getElementById(id);
    if (!field.value.trim()) {
        field.style.borderColor = 'red';
        return false;
    }
    field.style.borderColor = '#ddd';
    return true;
}